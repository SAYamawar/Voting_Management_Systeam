package com.votingmanagement.exception;

public class InvalidCandidateNameException extends Exception {
 public InvalidCandidateNameException (String message) {
	 super(message);
 }
}
