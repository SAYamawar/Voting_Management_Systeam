package com.votingmanagement.exception;

public class InvalidContactNumberException extends Exception{
	public InvalidContactNumberException (String message) {
        super(message);
    }
}
