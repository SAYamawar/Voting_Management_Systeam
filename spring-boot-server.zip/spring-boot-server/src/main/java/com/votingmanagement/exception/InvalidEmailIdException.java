package com.votingmanagement.exception;

public class InvalidEmailIdException extends Exception{




    public InvalidEmailIdException (String message) {
        super(message);
    }
}
