package com.votingmanagement.exception;

public class CandidateNotFoundException extends Exception {
	  public CandidateNotFoundException  (String message) {
	        super(message);
	  }
}
