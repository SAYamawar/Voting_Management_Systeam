package com.votingmanagement.exception;

public class DuplicatePartyNameException extends Exception {
	public DuplicatePartyNameException (String message) {
		super(message);
	}
}
