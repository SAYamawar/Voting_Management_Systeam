package com.votingmanagement.exception;

public class InvalidCandidatePartyNameException extends Exception {
	public InvalidCandidatePartyNameException(String message) {
		super(message);
	}
}
