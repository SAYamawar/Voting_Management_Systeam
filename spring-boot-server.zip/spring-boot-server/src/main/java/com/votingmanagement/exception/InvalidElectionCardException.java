package com.votingmanagement.exception;

public class InvalidElectionCardException extends Exception {
	public InvalidElectionCardException(String message) {
		super(message);
	}
}
