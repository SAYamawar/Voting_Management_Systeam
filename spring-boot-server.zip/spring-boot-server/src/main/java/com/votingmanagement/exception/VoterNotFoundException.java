package com.votingmanagement.exception;

public class VoterNotFoundException extends Exception {

	public VoterNotFoundException(String message) {
		super(message);
	}

}
