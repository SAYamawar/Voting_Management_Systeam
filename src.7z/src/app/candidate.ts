export interface ICandidate {
    candidateId: number;
    candidateName: string;
    candidateParty: string;
    vote: number;
}

