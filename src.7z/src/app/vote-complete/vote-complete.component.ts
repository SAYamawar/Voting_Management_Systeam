import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vote-complete',
  templateUrl: './vote-complete.component.html',
  styleUrls: ['./vote-complete.component.css']
})
export class VoteCompleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
